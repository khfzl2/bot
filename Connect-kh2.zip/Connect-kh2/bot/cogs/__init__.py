# Cogs package initialization
